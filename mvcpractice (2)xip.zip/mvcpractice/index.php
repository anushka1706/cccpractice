<?php

include_once './app/code/local/autoload.php';
include_once './app/Mage.php';




Mage::init();

