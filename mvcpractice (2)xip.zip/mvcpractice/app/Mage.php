<?php

class Mage
{

    private static $_singleton = [];


    private static $registry = [];
    private static $baseDir = 'C:/xampp/htdocs/assignment/mvcpractice';
    public static function init()
    {


        $frontcontroller = new Core_Controller_Front();
        $frontcontroller->init();
    }

    public static function getmodel($classname)
    {

        $classname = str_replace("/", "_Model_", $classname);
        
        $classname = ucwords(str_replace("/", "_", $classname), '_');
       

        return new $classname;
    }

    public static function getBlock($classname)
    {
        $name = explode("/", $classname);
        $classname = ucfirst(($name[0])) . "_" . "Block" . "_" . ucfirst(($name[1]));
       // print_r($classname);
        return new $classname();
    }

    public static function getSingleton($className)
    {


        if (isset(self::$_singleton[$className])) {
           
            return self::$_singleton[$className];
            
        } else {

            return  self::$_singleton[$className] = self::getModel($className);
        }
    }

    public static function register($key, $value)
    {
    }

    public static function registry($key)
    {
    }

    public static function getBaseDir($subDir = null)
    {
        if ($subDir) {

            // echo "<br>";
            // echo 'in mage getbasedir function'." " .self::$baseDir.'/'.$subDir;

            return self::$baseDir . '/' . $subDir;
        }

        return self::$baseDir;
    }

    public static function getBaseUrl()
    {

        return "http://localhost/assignment/mvcpractice/";
    }
}
