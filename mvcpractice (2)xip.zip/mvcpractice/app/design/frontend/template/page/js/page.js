console.log("in page.js");
    
