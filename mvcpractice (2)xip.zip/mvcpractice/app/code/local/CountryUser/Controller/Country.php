<?php

class CountryUser_Controller_Country extends Core_Controller_Front_Action
{

    public function formAction()
    {

        $layout = $this->getLayout();
        $child = $layout->getChild('content');
        $CountryUser =  $layout->createBlock('CountryUser/form')->setTemplate('countryuser/form.phtml');
        $child->addChild('CountryUser', $CountryUser);
        $layout->toHtml();
    }

    public function selectAction()
    {

        $country = $this->getRequest()->getParams('a_data');

        $name = $country['agent'];

        $agentData = Mage::getmodel('CountryUser/country')->getCollection()
            ->addFieldToFilter('name', $country['agent'])->getData();

        $countryId = [];

        foreach ($agentData as $_agentData) {
            $countryId[] = $_agentData->getId();
        }

        $data =  Mage::getmodel('CountryUser/country_user')->getCollection()
            ->addFieldToFilter('agent_id', ['IN' => $countryId])->getData();

         Mage::getBlock('CountryUser/form')->namesOptions($data);


        // $this->setRedirect('CountryUser/country/form');
    }
}
