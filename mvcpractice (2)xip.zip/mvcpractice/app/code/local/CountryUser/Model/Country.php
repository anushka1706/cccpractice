<?php

class CountryUser_Model_Country  extends Core_Model_Abstract{

public function init(){

    $this->resourceClass="CountryUser_Model_Resource_Country";
    $this->collectionClass="CountryUser_Model_Resource_Collection_Country";
    $this->_modelClass = "CountryUser/Country";
}
}