<?php

class CountryUser_Model_Country_User  extends Core_Model_Abstract{

public function init(){

    $this->resourceClass="CountryUser_Model_Resource_Country_User";
    $this->collectionClass="CountryUser_Model_Resource_Collection_Country_User";
    $this->_modelClass = "CountryUser/Country_User";
}
}