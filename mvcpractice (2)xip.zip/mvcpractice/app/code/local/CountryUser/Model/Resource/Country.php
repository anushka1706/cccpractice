<?php

class CountryUser_Model_Resource_Country extends Core_Model_Resource_Abstract{


    //  protected $_tableName=null;
    //  protected $_primaryKey=null;

    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "ccc_agent";
        $this->_primaryKey = "agent_id";
    }
}