<?php

class CountryUser_Model_Resource_Country_User extends Core_Model_Resource_Abstract{


    //  protected $_tableName=null;
    //  protected $_primaryKey=null;

    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "ccc_branch";
        $this->_primaryKey = "branch_id";
    }
}