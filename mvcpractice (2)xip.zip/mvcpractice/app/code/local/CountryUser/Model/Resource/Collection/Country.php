<?php

class CountryUser_Model_Resource_Collection_Country extends Core_Model_Resource_Collection_Abstract{
}