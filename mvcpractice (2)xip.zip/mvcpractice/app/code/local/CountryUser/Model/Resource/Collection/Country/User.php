<?php

class CountryUser_Model_Resource_Collection_Country_User extends Core_Model_Resource_Collection_Abstract{
}