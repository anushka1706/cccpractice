<?php

class CountryUser_Block_Form extends Core_Block_Template{

    public $branch = [];
    public function getBranch(){
        
 return Mage::getmodel('CountryUser/country_user');
     

    }

    public function namesOptions($data){

        foreach($data as $_data){

            $this->branch[$_data->getId()] = $_data->getName();
        }

        print_r($this->branch);
    }

    public function getAgent(){

        $options= Mage::getmodel('CountryUser/country')->getCollection();
        $mapping = [];
        foreach($options->getData() as $_options){

          $mapping[] = $_options->getName();
        }

        return $mapping;
    }

}