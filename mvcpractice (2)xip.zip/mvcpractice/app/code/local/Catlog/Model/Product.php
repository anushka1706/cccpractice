<?php

class Catlog_Model_Product  extends Core_Model_Abstract{

public function init(){

    $this->resourceClass="Catlog_Model_Resource_Product";
    $this->collectionClass="Catlog_Model_Resource_Collection_Product";
    $this->_modelClass = "catlog/product";
}


public function getStatus() {
    $mapping = [1=>'E', 0=>'D'];
    if(isset($this->data['status'])){

        return $mapping[$this->data['status']];

    }
}

public function getcategory_id(){
   
        $mapping=[1=> 'Electronics', 2=> 'BedRoom',3=> 'Decor',4=>'Dining & Kitchen',5=> 'Lighting',6=> 'Living Room' , 7=>'Mattresses',8=>'Office',9=>'Outdoor',10=>'Accessories',11=>'Footwear',12=>'Clothing',0=>'null',13=>'MakeUp',14=>'Fragnance',15=>'Western Wear',16=>'Ethnic Wear',17=>'Skin Care',18=>'Hair Care'];
        if(isset($this->data['category_id']))
        {

           
            return $mapping[$this->data['category_id']];
        }
        
    
    }

    protected function _beforeSave(){

        echo "before";

        if(!isset($this->_data['created_at']) || $this->_data['created_at']== ""){

            $this->data['created_at'] = '2015-01-01';
        }

        $this->data['updated_at'] = date('Y-m-d H:i:s');
        return $this;


        }


    }



