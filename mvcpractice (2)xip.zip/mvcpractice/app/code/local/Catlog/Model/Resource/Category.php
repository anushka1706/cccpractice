<?php

class Catlog_Model_Resource_Category extends Core_Model_Resource_Abstract{

    
    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "catalog_category";
        $this->_primaryKey = "category_id";
    }
    
}