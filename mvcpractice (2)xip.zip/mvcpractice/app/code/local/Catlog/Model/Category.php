<?php

class Catlog_Model_Category extends Core_Model_Abstract{

    public function init(){

        $this->resourceClass="Catlog_Model_Resource_Category";
        $this->collectionClass="Catlog_Model_Resource_Collection_Category";
        $this->_modelClass = "catlog/Category";
    }

}