<?php

class Catlog_Block_Admin_Product_Form extends Core_Block_Template{

    public function __construct(){
        

        $this->setTemplate('catlog/admin/product/form.phtml');
    }

    public function getProduct(){
       return Mage::getmodel('catlog/product')->load($this->getRequest()->getParams('id',0)); 
    }

    
}