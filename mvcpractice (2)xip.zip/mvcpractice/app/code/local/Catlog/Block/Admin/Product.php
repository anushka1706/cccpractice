<?php

class Catlog_Block_Admin_Product extends Core_Block_Template{


}