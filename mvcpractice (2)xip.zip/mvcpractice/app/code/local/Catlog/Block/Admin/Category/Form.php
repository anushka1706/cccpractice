<?php

class Catlog_Block_Admin_Category_Form extends Core_Block_Template{

    public function getCategoryData(){

        return Mage::getmodel('catlog/category')->load($this->getRequest()->getParams('id',0));
    }
    
}