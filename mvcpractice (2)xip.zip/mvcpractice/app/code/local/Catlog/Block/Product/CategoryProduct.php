<?php

class Catlog_Block_Product_CategoryProduct extends Core_Block_Template{

    public function getCategoryProducts(){

        $id = $this->getRequest()->getParams('id',0);
      $data =  Mage::getmodel('catlog/product')->getCollection()->addFieldToFilter('category_id',$id)->getData();
return $data;

    }
}