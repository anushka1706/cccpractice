<?php

class Catlog_Block_Product_View extends Core_Block_Template{

    public function getView(){

        return Mage::getmodel('catlog/product')->load($this->getRequest()->getParams('id',0));
    }

    public function getAllProducts(){

        return Mage::getmodel('catlog/product')->getCollection();
    }

    
}