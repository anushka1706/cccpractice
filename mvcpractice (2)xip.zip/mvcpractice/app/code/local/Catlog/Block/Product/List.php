<?php

class Catlog_Block_Product_List extends Core_Block_Template{

    
}