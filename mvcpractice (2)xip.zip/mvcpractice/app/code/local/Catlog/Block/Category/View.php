<?php

class Catlog_Block_Category_View extends Core_Block_Template{

    
    
}