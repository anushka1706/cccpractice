<?php

class Catlog_Controller_Category extends Core_Controller_Admin_Action{

    public function formAction(){


    }

    public function viewAction(){


        $layout =  $this->getLayout();
        $child = $layout->getChild('content');
       // $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/header.css');

        //$layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/customer/list.css');

        $view = $layout->createBlock('catlog/category_view')->setTemplate('catlog/category/view.phtml');

        $child->addChild('view', $view);

        $layout->toHtml();
        
    }
}