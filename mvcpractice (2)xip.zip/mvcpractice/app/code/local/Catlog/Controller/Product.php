<?php

class Catlog_Controller_Product extends Core_Controller_Front_Action
{




  public function viewAction()
  {
    if ($id = $this->getRequest()->getParams('id', 0)) {

      $layout =  $this->getLayout();
      $child = $layout->getChild('content');
      //  $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/product/list.css');
      $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/catlog/product/view.css');

      $view = $layout->createBlock('catlog/product_view')->setTemplate('catlog/product/view.phtml');

      //print_r($productList);
      $child->addChild('view', $view);

      $layout->toHtml();

    } 
    
    else {

      $layout =  $this->getLayout();
      $child = $layout->getChild('content');
      //  $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/product/list.css');
      $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/catlog/product/view.css');

      $allProducts = $layout->createBlock('catlog/product_view')->setTemplate('catlog/product/allproducts.phtml');

      //print_r($productList);
      $child->addChild('allproducts', $allProducts);

      $layout->toHtml();
     
    }
  }


public function categoryAction(){

  $layout =  $this->getLayout();
  $child = $layout->getChild('content');
  //  $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/product/list.css');
  $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/catlog/product/view.css');

  $categoryproduct = $layout->createBlock('catlog/product_CategoryProduct')->setTemplate('catlog/product/categoryproduct.phtml');

  //print_r($productList);
  $child->addChild('categoryproduct', $categoryproduct);

  $layout->toHtml();

}
  // public function saveAction(){


  //     $data= $this->getRequest()->getParams('p_data');

  //     echo "<pre>";

  //     //print_r($data);

  //     $productModel = Mage::getmodel('catlog/product') ;

  //     $productModel->setData($data)->save();
  //    // print_r($productModel);

  //     print_r($productModel);




  // }

  // public function listAction(){

  //     echo "rtfeh";

  //     $layout =  $this->getLayout();
  //     $child = $layout->getChild('content');

  //     $productList = $layout->createBlock('catlog/admin_product')->setTemplate('product/list.phtml');

  //    //print_r($productList);
  //    $child->addChild('list', $productList);

  //     $layout->toHtml();



  // }
}
