<?php

class Status_Model_Status extends Core_Model_Abstract{

    public function getStatus(){

        return $map = [
             0=>'select',
             1=>'Place Order',
             2=>'Shipped',
             3=>'Cancelled',
             4=>'In-Transit',
             5=>'Refunded'
        ];
 
     
     }
    
}

?>