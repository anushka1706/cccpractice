<?php

class Import_Model_Resource_Import extends Core_Model_Resource_Abstract{

    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "import";
        $this->_primaryKey = "import_id";
    
}
}