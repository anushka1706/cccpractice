<?php

class Import_Model_Resource_Collection_Import extends Core_Model_Resource_Collection_Abstract{
    
}