<?php

class Import_Controller_Import extends Core_Controller_Front_Action
{

    public function readAction()
    {

        $path = Mage::getBaseUrl() . 'media/import/Book1.csv';
        $row = 1;
        $header = [];
        $array = [];
        if (($open = fopen($path, "r")) !== false) {
            while (($data = fgetcsv($open, 1000, ",")) !== false) {
                if ($row == 1) {
                    $header = $data;
                    $row++;
                    continue;
                }
                $array = array_combine($header, $data);
                echo "<pre>";
                print_r($array);
                $importData = json_encode($array);
                $import = Mage::getmodel('import/import')->addData('data', $importData)->addData('status', 1)->save();
                print_r($importData);
            }
        }
        // $this->setRedirect('Import/Import/Import');
    }

    public function importAction()
    {

        $import = Mage::getmodel('import/import')->getCollection();
        foreach ($import->getData() as $_import) {

            $json = json_decode($_import->getImportData(),true);
    
        }
    }
}
