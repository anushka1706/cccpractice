<?php

class Admin_Model_User extends Core_Controller_Admin_Action
{

    const USERNAME = "admin";
    const PASSWORD = "admin123";


}

/*
table banner:
id,title,uimage,status,showon

banner/block/admin/name

banner/mode/name=front
catlog/category/view?id=1/view of all category id -catlog/controller/category action for template for customer: catlog/block/category/view.php and product for user and 
catlog/product/view?id=1 / addtocart/quantity/description on submit sales_quote_add post data print

banner content inside content 




*/ 