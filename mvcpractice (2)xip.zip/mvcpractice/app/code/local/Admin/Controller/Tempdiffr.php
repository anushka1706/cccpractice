<?php

class Admin_Controller_Tempdiffr extends Core_Controller_Admin_Action{

    public function listAction(){

    }

    
}