<?php

class Admin_Controller_Catlog_Category extends Core_Controller_Admin_Action{

    protected $_actionName = ['login'];


public function formAction(){
    $layout =  $this->getLayout();
    $child = $layout->getChild('content');
   // $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/header.css');

    //$layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/customer/list.css');

    $form = $layout->createBlock('catlog/admin_category_form')->setTemplate('catlog/admin/category/form.phtml');

    $child->addChild('form', $form);

    $layout->toHtml();
}

public function saveAction(){

    $data = $this->getRequest()->getParams('cat_data');
    $category = Mage::getModel("catlog/category");
    $category->setData($data);
    $category->save();
    
$this->setRedirect("admin/catlog_category/form?id={$category->getId()}");
}

}