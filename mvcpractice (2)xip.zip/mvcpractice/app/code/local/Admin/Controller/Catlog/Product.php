<?php

class Admin_Controller_Catlog_Product extends Core_Controller_Admin_Action
{
    protected $_actionName = ['login'];


    public function saveAction()
    {

        // {
        //     try {
        //         if(!$this->getRequest()->isPost()) {
        //             throw new Exception("Request is not valid");
        //         }
        //         $data = $this->getRequest()->getParams('p_data');
        //         if(!isset($data['price']) || !is_numeric($data['price'])) {
        //             throw new Exception("Price is required or should be numeric");
        //         }
        //         if(!isset($data['price']) || !is_numeric($data['price'])) {
        //             throw new Exception("Price is required or should be numeric");
        //         }

        // $id = (isset($data['product_id'])) ? $data['product_id'] : 0;
        $data = $this->getRequest()->getParams('p_data');
        $product = Mage::getModel("catlog/product");
        $product->setData($data);
        $product->save();

        $this->setRedirect("admin/catlog_product/form?id={$product->getId()}");
    }

    // catch(Exception $e) {
    //     var_dump($e->getMessage());
    // }




    public function formAction()
    {


        //echo "78";

        $layout =  $this->getLayout();

        // $layout->getChild('head')->addJs('js/page.js');
        // $layout->getChild('head')->addJs('js/head.js');
        // $layout->getChild('head')->addCss('css/head.css');
        // $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/product/form.css');


        // $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/header.css');
        $child = $layout->getChild('content');

        $productForm = $layout->createBlock('catlog/admin_product_form');


        $child->addChild('form', $productForm);


        $layout->toHtml();
    }


    public function listAction()
    {

        $layout =  $this->getLayout();

        // $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/header.css');

        // $layout->getChild('head')->addJs('js/page.js');
        // $layout->getChild('head')->addJs('js/head.js');
        // $layout->getChild('head')->addCss('css/head.css');
        // $layout->getChild('head')->addCss('css/page.css');

        //  $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/product/list.css');

        $layout =  $this->getLayout();
        $child = $layout->getChild('content');

        $productList = $layout->createBlock('catlog/admin_product_list')->setTemplate('catlog/admin/product/list.phtml');

        //print_r($productList);
        $child->addChild('list', $productList);

        $layout->toHtml();
    }

    public function deleteAction()
    {


        //print_r($model);

        Mage::getmodel('catlog/product')->load($this->getRequest()->getParams('id', 0))
            ->delete();

        // $model->delete($id);

    }
}
