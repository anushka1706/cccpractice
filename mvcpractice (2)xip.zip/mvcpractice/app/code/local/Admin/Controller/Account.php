<?php

class Admin_Controller_Account extends Core_Controller_Admin_Action
{

    protected $_allowActions = [
        "login"
    ];


    public function testAction()
    {

        echo "protected";
    }


    public function loginAction()
    {

        if (!$this->getRequest()->isPost()) {

            $layout = $this->getLayout();
            //$layout->getChild('head')->addCss(Mage::getBaseUrl() . "app/skin/css/header.css");
            $child = $layout->getchild('content');

            $login = $layout->createBlock('admin/login')->setTemplate('admin/admin.phtml');

            //$header = $layout->createBlock('admin/header')->setTemplate('admin/header.phtml');

            $child->addChild('login', $login);

            echo get_class($child);

            $layout->toHtml();
        } else {

            $adminData = $this->getRequest()->getParams('a_data');
            $username = $adminData['email'];
            $password = $adminData['password'];

            if ($username == Admin_Model_User::USERNAME && $password == Admin_Model_User::PASSWORD) {

                Mage::getSingleton('core/session')->set('logged_in_admin_username', $username);

                $this->setRedirect('admin/catlog_product/list');
            } else {

                echo "Wrong credentials";
                // $this->setRedirect('admin/account/login');
                Mage::getSingleton('core/session')->remove('logged_in_admin_username');
            }
        }
    }

    public function dashboardAction()
    {

        echo "dashboard";
    }
}
// var_dump(Admin_Model_User::USERNAME);
// var_dump(Admin_Model_User::PASSWORD);
