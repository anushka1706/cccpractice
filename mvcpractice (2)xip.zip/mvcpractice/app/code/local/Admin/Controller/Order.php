<?php

class Admin_Controller_Order extends Core_Controller_Admin_Action{

    public function listAction(){

        $layout =  $this->getLayout();
        $child = $layout->getChild('content');
    
        $list = $layout->createBlock('sales/admin_order_list')->setTemplate('sales/admin/order/list.phtml');
    
        $child->addChild('orderlist', $list);
    
        $layout->toHtml();
    }

    public function saveAction(){

        $status = $this->getRequest()->getParams('order');
        $id = $this->getRequest()->getParams('id');
$status = $status['status'];

   echo $status;

       $order =  Mage::getmodel('sales/order_statusHistory')
        ->setData([
            'to_status'=>$status,
            'order_id'=>$id
        ])->save();

        Mage::getSingleton('sales/order')->addData('order_id',$order->getOrderId())->addData('status',$order->getToStatus())->save();        //print_r($order);
        $this->setRedirect('admin/order/list');


    }

    public function viewAction(){

        $layout =  $this->getLayout();
        $child = $layout->getChild('content');
    
        $orderview = $layout->createBlock('sales/admin_order_view')->setTemplate('sales/admin/order/view.phtml');
    
        $child->addChild('orderview', $orderview);
    
        $layout->toHtml();
    }
}