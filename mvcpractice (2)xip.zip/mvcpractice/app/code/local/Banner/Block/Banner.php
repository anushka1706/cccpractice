<?php

class Banner_Block_Banner extends Core_Block_Template{


    public function getBanner(){

        return Mage::getmodel('banner/banner');
    }

    
}