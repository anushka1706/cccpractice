<?php

class Banner_Block_Admin_View extends Core_Block_Template{

    public function getBannerView(){

        return Mage::getmodel('banner/banner');

    }
}