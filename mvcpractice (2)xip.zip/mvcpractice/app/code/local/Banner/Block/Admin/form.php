<?php

class Banner_Block_Admin_Form extends COre_Block_Template{


    public function getBanner(){

    return Mage::getmodel('banner/banner')->load($this->getRequest()->getParams('id',0));

    }
}