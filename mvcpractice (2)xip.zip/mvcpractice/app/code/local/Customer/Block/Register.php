<?php

class Customer_Block_Register extends Core_Block_Layout{

    public function getCustomer(){
        return Mage::getmodel('customer/customer')->load($this->getRequest()->getParams('id',0)); 
     }

    
}