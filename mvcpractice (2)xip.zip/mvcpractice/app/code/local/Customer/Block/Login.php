<?php

class Customer_Block_Login extends Core_Block_Template{


    
}