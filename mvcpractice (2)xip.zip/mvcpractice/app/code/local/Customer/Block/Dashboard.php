<?php

class Customer_Block_Dashboard extends Core_Block_Template{

    public function getCustomerAddress(){

        return Mage::getmodel('customer/address')->getCollection()
        ->addFieldToFilter('customer_id',Mage::getSingleton('core/session')->get('logged_in_customer_id'))->getData();
    }
    
public function getCustomerInfo(){
    return Mage::getmodel('customer/customer')->getCollection()
    ->addFieldToFilter('customer_id',Mage::getSingleton('core/session')->get('logged_in_customer_id'))->getData();
}
}