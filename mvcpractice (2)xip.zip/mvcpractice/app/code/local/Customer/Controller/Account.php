<?php

class Customer_Controller_Account extends Core_Controller_Front_Action
{

    protected $_allowActions = ['dashboard'];

    public function __construct()
    {

        $this->init();
    }


    public function init()
    {

        $action = $this->getRequest()->getActionName();
        if (in_array($action, $this->_allowActions)) {

            $customer_Id =  Mage::getSingleton('core/session')->get('logged_in_customer_id');
            if (!($customer_Id)) {

                $this->setRedirect('customer/account/login');
            }
        }
    }

    public function registerAction()
    {

        $layout =  $this->getLayout();
        $child = $layout->getChild('content');
        // $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/header.css');

        // $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/customer/register.css');

        $register = $layout->createBlock('customer/register')->setTemplate('customer/register.phtml');
   
        $child->addChild('register', $register);

        print_r($layout);
        $layout->toHtml();
    }

    public function saveAction()
    {

        // try{
        //     if(!$this->getRequest()->isPost())
        //     {
        //         throw new Exception("Request is not valid");
        //     }
        //     $data = $this->getRequest()->getParams('customer');

        //     if(!isset($data['price']) || !is_numeric($data['price']))
        //     {
        //         throw new Exception('price must in number');
        //     }

        $data = $this->getRequest()->getParams('c_data');
        $customerModel = Mage::getModel('customer/customer');
        $customerModel->setData($data)->save();

        // }
        // catch(Exception $e){
        //     var_dump($e->getMessage());
        // }

    }



    public function loginAction()

    {
        if (!$this->getRequest()->isPost()) {
            $layout = $this->getLayout();
            $child = $layout->getChild('content');
            $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/customer/login.css');
            // $layout->removeChild('header');
            // $layout->removeChild('footer');
            $layout->getChild('head')->addJs(Mage::getBaseUrl() . 'app/skin/js/jquery.js');
            $loginForm =  $layout->createBlock('customer/login')->setTemplate('customer/login.phtml');
            $child->addChild('login', $loginForm);
            $layout->toHtml();
        } else {

            try {
                
                $data = $this->getRequest()->getParams('c_data');

               // print_r($data);
            
                $message = [];
                // echo "<pre>";
                // print_r($data);
                $custmerModel = Mage::getmodel("customer/customer")->getCollection()
                    ->addFieldToFilter('customer_email', "{$data['customer_email']}")
                    ->addFieldToFilter('password', "{$data['password']}");
                $dataModel = $custmerModel->getData();
                if (sizeof($dataModel) == 0) {

                    //echo"oo";
                    Mage::getSingleton('core/session')->remove('logged_in_customer_id');
                    throw new Exception('Email Id And Password Is Invalid');
                } 
                else {

                    foreach ($dataModel as $data) {
                        Mage::getSingleton('core/session')->set('logged_in_customer_id', $data->getCustomerId());


                        $message = [
                            'type' => 'success',
                            'message' => 'Successful'
                        ];
                    }
                }
            } catch (Exception $e) {

                // var_dump($e->getMessage());

                $message = [
                    'type' => 'error',
                    'message' => $e->getMessage()
                ];
            }

            echo  json_encode($message);
        }
    }


    public function dashboardAction()
    {
        $layout =  $this->getLayout();

        $child = $layout->getChild('content');
        //$layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/header.css');
        // $layout->getChild('head')->addCss(Mage::getBaseUrl() . 'app/skin/css/customer/dashboard.css');
        $dashboard = $layout->createBlock('customer/dashboard')->setTemplate('customer/dashboard.phtml');
        $child->addChild('dashboard', $dashboard);

        $layout->toHtml();
    }




    public function forgotpasswordAction()
    {
    }
}
