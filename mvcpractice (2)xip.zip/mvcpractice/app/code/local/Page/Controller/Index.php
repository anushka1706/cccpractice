<?php

class Page_Controller_Index extends Core_Controller_Front_Action{


    public function indexAction(){
        
       $layout =  $this->getLayout();

   

      $layout->getChild('head')->addJs('js/page.js');
      $layout->getChild('head')->addJs('js/head.js');
      $layout->getChild('head')->addCss('css/page.css');
      $layout->getChild('head')->addCss('css/head.css');
      $layout->getChild('head')->addJs('https://code.jquery.com/jquery-3.5.1.slim.min.js');
      $layout->getChild('head')->addJs(' https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js');
      $layout->getChild('head')->addJs('https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
      $layout->getChild('head')->addCss(Mage::getBaseUrl().'app/skin/css/banner/banner.css');
      $child=$layout->getChild('content');
   
    
      $banner=$layout->createBlock('banner/banner')->setTemplate('banner/banner.phtml');
      $child->addChild('banner',$banner);

      
     
      $layout->toHtml();

     
}

public function testAction(){

    
   
    

   $product =  Mage::getSingleton('core/session');
   print_r($_SESSION);



}
}