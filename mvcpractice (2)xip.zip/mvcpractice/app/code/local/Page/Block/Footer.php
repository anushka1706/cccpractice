<?php

class Page_Block_Footer extends Core_Block_Template {

    public function __construct(){

        $this->setTemplate('page/footer.phtml');
    }

}