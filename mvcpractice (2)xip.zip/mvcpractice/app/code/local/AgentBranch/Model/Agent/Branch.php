<?php

class AgentBranch_Model_Agent_Branch  extends Core_Model_Abstract{

public function init(){

    $this->resourceClass="AgentBranch_Model_Resource_Agent_Branch";
    $this->collectionClass="AgentBranch_Model_Resource_Collection_Agent_Branch";
    $this->_modelClass = "AgentBranch/Agent_Branch";
}
}