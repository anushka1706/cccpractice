<?php

class AgentBranch_Model_Agent  extends Core_Model_Abstract{

public function init(){

    $this->resourceClass="AgentBranch_Model_Resource_Agent";
    $this->collectionClass="AgentBranch_Model_Resource_Collection_Agent";
    $this->_modelClass = "AgentBranch/Agent";
}
}