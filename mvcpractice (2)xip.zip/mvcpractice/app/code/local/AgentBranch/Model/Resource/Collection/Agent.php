<?php

class AgentBranch_Model_Resource_Collection_Agent extends Core_Model_Resource_Collection_Abstract{
    
}