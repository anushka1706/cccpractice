<?php

class AgentBranch_Model_Resource_Collection_Agent_Branch extends Core_Model_Resource_Collection_Abstract{
    
}