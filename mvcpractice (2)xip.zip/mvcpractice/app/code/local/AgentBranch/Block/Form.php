<?php

class AgentBranch_Block_Form extends Core_Block_Template{

    public $branch = [];
    public function getBranch(){
 return Mage::getmodel('agentBranch/agent_branch');
     

    }

    public function namesOptions($data){

        foreach($data as $_data){

            $this->branch[$_data->getId()] = $_data->getName();
        }

        print_r($this->branch);
    }

    public function getAgent(){

        $options= Mage::getmodel('agentBranch/agent')->getCollection();
        $mapping = [];
        foreach($options->getData() as $_options){

          $mapping[] = $_options->getName();
        }

        return $mapping;
    }

}