<?php

class AgentBranch_Controller_Agent extends Core_Controller_Front_Action
{

    public function formAction()
    {

        $layout = $this->getLayout();
        $child = $layout->getChild('content');
        $viewCart =  $layout->createBlock('agentBranch/form')->setTemplate('agentBranch/form.phtml');
        $child->addChild('viewCart', $viewCart);
        $layout->toHtml();
    }

    public function selectAction()
    {

        $country = $this->getRequest()->getParams('a_data');

        $name = $country['agent'];

        $agentData = Mage::getmodel('agentbranch/agent')->getCollection()
            ->addFieldToFilter('name', $country['agent'])->getData();

        $countryId = [];

        foreach ($agentData as $_agentData) {
            $countryId[] = $_agentData->getId();
        }

        $data =  Mage::getmodel('agentBranch/agent_branch')->getCollection()
            ->addFieldToFilter('agent_id', ['IN' => $countryId])->getData();

         Mage::getBlock('agentBranch/form')->namesOptions($data);


        // $this->setRedirect('agentBranch/agent/form');
    }
}
