<?php

class Sales_Controller_Quote extends Core_Controller_Front_Action
{
    protected $_allowActions = ['login'];



    public function init()
    {

        $action = $this->getRequest()->getActionName();
        if (in_array($action, $this->_allowActions)) {

            $customer_Id =  Mage::getSingleton('core/session')->get('logged_in_customer_id');
            if (!($customer_Id)) {

                $this->setRedirect('customer/account/login');
            }
        }
    }


    public function addAction()
    {

        $product = $this->getRequest()->getParams('q_data');
        print_r($product);

        Mage::getmodel('sales/quote')->addProduct($product);

        $this->setRedirect('sales/quote/view');
    }


    public function viewAction()
    {
        $layout = $this->getLayout();
        $child = $layout->getChild('content');
        $viewCart =  $layout->createBlock('sales/view')->setTemplate('sales/view.phtml');
        $child->addChild('viewCart', $viewCart);
        $layout->toHtml();
    }

    public function checkoutAction()
    {

        $id = Mage::getSingleton('core/session')->get('logged_in_customer_id');
        if (!$id) {
            $this->setRedirect('customer/account/login');
        } else {

            $layout = $this->getLayout();
            $child = $layout->getChild('content');
            $layout->getChild('head')->addJs(Mage::getBaseUrl() . 'app/skin/js/jquery.js');
            $checkout =  $layout->createBlock('sales/checkout')->setTemplate('sales/checkout.phtml');
            $child->addChild('checkout', $checkout);
            $layout->toHtml();
        }
    }
    public function saveAction()
    {

        $addressData = $this->getRequest()->getParams('quote_customer');
        $shippingData = $this->getRequest()->getParams('shipping');
        $paymentData = $this->getRequest()->getParams('payment');

        // print_r($data);
        Mage::getSingleton('sales/quote')->addCustomer($addressData);
        Mage::getSingleton('sales/quote')->addShipping($shippingData);
        Mage::getSingleton('sales/quote')->addPayment($paymentData);

        $this->setRedirect('sales/quote/convert');
    }

    public function updateAction()
    {

        $formData = $this->getRequest()->getParams('item_data');
        // print_r($formData);
        $id = $formData['product_id'];
        $qty = $formData['qty'];
        $quote = Mage::getModel('sales/quote');
        $quote->initQuote();
        $data = $quote->getItemCollection()->addFieldToFilter('product_id', $id)->getFirstData();
        $data->addData('qty', $qty);
        $data->save();
        $quote->save();
        $this->setRedirect('sales/quote/view');
    }

    public function removeAction()
    {
        $cartDelete = Mage::getmodel('sales/quote_item')
            ->load($this->getRequest()->getParams('id', 0))
            ->delete();
        $quote = Mage::getmodel('sales/quote');
        $quote->initQuote();
        $quote->save();
        $this->setRedirect('sales/quote/view');
    }

    public function orderplacedAction()
    {

        $layout = $this->getLayout();
        $child = $layout->getChild('content');
        $orderPlaced =  $layout->createBlock('sales/order_orderplaced')->setTemplate('sales/order/orderplaced.phtml');
        $child->addChild('orderplaced', $orderPlaced);
        $layout->toHtml();
    }

    public function convertAction()
    {

        Mage::getmodel('sales/quote')->convert();
        $this->setRedirect('sales/quote/orderplaced');
    }
}
