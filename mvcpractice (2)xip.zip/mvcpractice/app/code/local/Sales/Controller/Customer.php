<?php

class Sales_Controller_Customer extends Core_Controller_Front_Action{

    public function viewAction(){

        $layout = $this->getLayout();
        $child = $layout->getChild('content');
        $viewOrder =  $layout->createBlock('sales/customer_viewOrder')->setTemplate('sales/customer/vieworder.phtml');
        $child->addChild('viewOrdercustomer', $viewOrder);
        $layout->toHtml();
    
    }
}