<?php

class Sales_Block_View extends Core_Block_Template
{

    public function viewItems()
    {

        $quote = Mage::getmodel('sales/quote');
        $quote->initQuote();

        $id  = $quote->getId();

        $item = Mage::getmodel('sales/quote_item')->getCollection()->addFieldToFilter('quote_id', $id);

        $product_id = [];

        foreach ($item->getdata() as $_item) {

            $product_id[] = $_item->getProductId();
        }

        return $product = Mage::getmodel('catlog/product')->getCollection()->addFieldToFilter('product_id', ['IN' => $product_id]);
    }

    public function getItem()
    {

        $salesQuote = $this->quote();
        $item = $salesQuote->getItemCollection();

        return $item;
    }

    public function quote()
    {

        $quote = Mage::getmodel('sales/quote');

        $quote->initQuote();

        return $quote;
    }
}
