<?php

class Sales_Block_Admin_Order_View extends Core_Block_Template{



    public function getCustomerData(){

     $customerId = Mage::getSingleton('core/session')->get('logged_in_customer_id');
        return $data = Mage::getmodel('sales/order_customer')->getCollection()->addFieldToFilter('customer_id',$customerId)->getData();
        
    }

    public function getSalesOrderData(){

       
    }

   


}

?>