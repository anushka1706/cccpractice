<?php 

class Sales_Block_Admin_Order_List extends Core_Block_Template{

    public function getOrder(){

        return Mage::getmodel('sales/order')->getCollection()->getData();
    }
    public function getCustomer(){

        return Mage::getmodel('sales/order_customer')->getCollection()->getData();
    }

    public function getStatusModel(){

      $status= Mage::getmodel('status/status')->getStatus();
      return $status;

    
    }
}