<?php

class Sales_Block_Order_Orderplaced extends Core_Block_Template
{

    public function orderData()
    {

        $quote =  Mage::getmodel('sales/quote');
        $quote->initQuote();
        $data = Mage::getmodel('sales/quote')->getCollection()->addFieldToFilter('quote_id', $quote->getId())->getFirstData();
        $order = Mage::getmodel('sales/order')->getCollection()->addFieldToFilter('order_id', $data->getOrderId());

        return $order;
    }
}
