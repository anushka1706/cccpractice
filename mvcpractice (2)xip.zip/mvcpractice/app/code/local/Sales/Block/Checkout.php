<?php

class Sales_Block_Checkout extends Core_Block_Template
{

    public function getItems()
    {
        $quote = Mage::getmodel('sales/quote');

        $quote->initQuote();

        $id  = $quote->getId();

        $item = Mage::getmodel('sales/quote_item')->getCollection()->addFieldToFilter('quote_id', $id);

        $qty = [];

        foreach ($item->getdata() as $_item) {

            $qty[$_item->getproduct_id()] = $_item->getQty();
        }
        return $qty;
    }

    public function listItems()
    {
        $quote = Mage::getmodel('sales/quote');


        $quote->initQuote();

        $id  = $quote->getId();

        $item = Mage::getmodel('sales/quote_item')->getCollection()->addFieldToFilter('quote_id', $id);

        $product_id = [];

        foreach ($item->getdata() as $_item) {
            $product_id[] = $_item->getProductId();
        }


        return $product = Mage::getmodel('catlog/product')->getCollection()->addFieldToFilter('product_id', ['IN' => $product_id]);
    }

    public function quote()
    {

        $quote = Mage::getmodel('sales/quote');
        $quote->initQuote();
        $data  = $quote->getCollection()->addFieldToFilter('quote_id', $quote->getId());

        foreach ($data->getdata() as $_data) {

            $total  = $_data->getGrandTotal();
        }
        return $total;
    }

    public function getCustomerData()
    {

        $id = Mage::getSingleton('core/session')->get('logged_in_customer_id');
        $customerdata = Mage::getmodel('customer/address')->getCollection()->addFieldToFilter('customer_id', $id);
        return $customerdata;
    }


    public function getCustomer()
    {

        $data = Mage::getmodel('customer/customer')->getCollection()->addFieldToFilter('customer_id', Mage::getSingleton('core/session')->get('logged_in_customer_id'))->getFirstData();
        return $data;
    }

    public function getquote()
    {
        $id = Mage::getSingleton('core/session')->get('quote_id');

        return $id;
    }

    public function getQuoteCustomer()
    {

        return Mage::getmodel('sales/quote_customer')->getId();
    }

    public function getShippingid()
    {
        return Mage::getmodel('sales/quote_shipping')->getId();
    }

    public function getPaymentId(){

        return Mage::getmodel('sales/quote_payment')->getId();
    }
}
