<?php

class Sales_Block_Customer_ViewOrder extends Core_Block_Template{

    public function getOrderItemsDetails(){


        $quote =  Mage::getmodel('sales/quote');
        $quote->initQuote();
        $data =  Mage::getmodel('sales/quote')->getCollection()
        ->addFieldToFilter('quote_id',$quote->getId())
        ->addFieldToFilter('customer_id',Mage::getSingleton('core/session')->get('logged_in_customer_id'))->getFirstData();
        $items =  Mage::getmodel('sales/order_item')->getCollection()
        ->addFieldToFilter('order_id',$data->getOrderId())->getData();
        return $items;
    }

    public function getOrderDeatils(){

        $quote =  Mage::getmodel('sales/quote');
        $quote->initQuote();
        $data =  Mage::getmodel('sales/quote')->getCollection()
        ->addFieldToFilter('quote_id',$quote->getId())
        ->addFieldToFilter('customer_id',Mage::getSingleton('core/session')->get('logged_in_customer_id'))->getFirstData();
        return Mage::getmodel('sales/order')->load($data->getOrderId());
    }
}