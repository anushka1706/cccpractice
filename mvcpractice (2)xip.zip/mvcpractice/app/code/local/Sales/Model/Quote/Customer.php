<?php

class Sales_Model_Quote_Customer extends Core_Model_Abstract
{

    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Quote_Customer";
        $this->collectionClass = "Sales_Model_Resource_Collection_Quote_Customer";
        $this->_modelClass = "sales/quote_customer";
    }

    public function addCustomerData($data)
    {

        $quote = Mage::getmodel('sales/quote');
        $quote->initQuote();
        $id = Mage::getSingleton('core/session')->get('logged_in_customer_id');
        $customerdata = Mage::getmodel('customer/customer')->getCollection()->addFieldToFilter('customer_id', $id)->getFirstData();

        $this->setData($data)
            ->addData('quote_id', $quote->getId())

            ->addData('customer_id', $customerdata->getId())
            ->addData('email', $customerdata->getCustomer_Email())
            ->save();
            
        return $this;
    }
}
