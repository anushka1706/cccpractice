<?php

class Sales_Model_Quote_Shipping extends Core_Model_Abstract
{

    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Quote_Shipping";
        $this->collectionClass = "Sales_Model_Resource_Collection_Quote_Shipping";
        $this->_modelClass = "sales/quote_shipping";
    }

    public function addShippingMethod($data){

       $quote = Mage::getmodel('sales/quote');
       $quote->initQuote();
       if($quote->getId()){
        $shippingData = $this->getCollection()->addFieldToFilter('quote_id', $quote->getId())->getFirstData();
        $shippingId = ($shippingData && $shippingData->getId()) ? $shippingData->getId() : 0;
       }
        $this->setData($data)->addData('quote_id',$quote->getId())
        ->addData('shipping_id',$shippingId)->save();

        return $this;

    }
    
}