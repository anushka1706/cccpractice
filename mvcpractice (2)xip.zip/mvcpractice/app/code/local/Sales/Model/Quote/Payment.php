<?php

class Sales_Model_Quote_Payment extends Core_Model_Abstract
{

    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Quote_Payment";
        $this->collectionClass = "Sales_Model_Resource_Collection_Quote_Payment";
        $this->_modelClass = "sales/quote_payment";
    }

 public function addPaymentMethod($data){

    $quote = Mage::getmodel('sales/quote');
    $quote->initQuote();
    if($quote->getId()){
        $paymentData = $this->getCollection()->addFieldToFilter('quote_id', $quote->getId())->getFirstData();
        $paymentId = ($paymentData && $paymentData->getId()) ? $paymentData->getId() : 0;
       }
        $this->setData($data)->addData('quote_id',$quote->getId())
        ->addData('payment_id',$paymentId)->save();

    

     return $this;

 }
}