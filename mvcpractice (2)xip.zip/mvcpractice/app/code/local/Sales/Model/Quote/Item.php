<?php

class Sales_Model_Quote_Item extends Core_Model_Abstract
{

    protected $_product = null;
    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Quote_Item";
        $this->collectionClass = "Sales_Model_Resource_Collection_Quote_Item";
        $this->_modelClass = "sales/quote_item";
    }

    protected function _beforeSave()
    {

        if ($this->getProductId()) {

            $row_total = $this->getProduct()->getPrice() * $this->getQty();

            $this->addData('row_total', $row_total);
            $this->addData('price', $this->getProduct()->getPrice());
        }
    }

    public function getProduct()
    {

        if(is_null($this->_product)){
        $this->_product = Mage::getmodel('catlog/product')->load($this->getProductId());
    }

    return $this->_product;
}

    public function addItem($quote, $productId, $qty)
    {

        $item = $quote->getItemCollection()->addFieldToFilter('product_id', $productId)->getFirstData();

        $itemId = ($item &&  $item->getId()) ? $item->getId() : '0';

        $qty = ($item && $item->getQty()) ? $item->getQty() + $qty : $qty;

        $data = [
            'product_id' => $productId,
            'quote_id' => $quote->getId(),
            'row_total' => '0',
            'item_id' => $itemId,
            'qty' => $qty,
            'price' => '0'
        ];

        Mage::getModel('sales/quote_item')->setData($data)->save();
    }
}
