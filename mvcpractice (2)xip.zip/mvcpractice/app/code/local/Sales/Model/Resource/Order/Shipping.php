<?php

class Sales_Model_Resource_Order_Shipping extends Core_Model_Resource_Abstract{

    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "sales_order_shipping_method";
        $this->_primaryKey = "shipping_id";
    
}
}