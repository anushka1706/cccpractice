<?php

class Sales_Model_Resource_Collection_Order_Item extends Core_Model_Resource_Collection_Abstract{

}