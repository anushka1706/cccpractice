<?php

class Sales_Model_Quote extends Core_Model_Abstract
{

    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Quote";
        $this->collectionClass = "Sales_Model_Resource_Collection_Quote";
        $this->_modelClass = "sales/quote";
    }

    protected  function _beforeSave()
    {

        $grand_total = 0;
        foreach ($this->getItemCollection()->getData() as $_item) {

            $grand_total += $_item->getRowTotal();
        }

        $this->addData('grand_total', $grand_total);
    }
    public function initQuote()
    {
        $quoteId =  Mage::getSingleton('core/session')->get('quote_id');
        $quoteId =  (!$quoteId) ? 0 : $quoteId;

        $customer_id =  Mage::getSingleton('core/session')->get('logged_in_customer_id');

        $customer_id =  (!$customer_id) ? 0 : $customer_id;

        if ($customer_id) {
            // echo "in customer";
            $customerQuote1 = Mage::getSingleton('sales/quote')->getCollection()->addFieldToFilter('customer_id', $customer_id)->addFieldToFilter('order_id', 0)->getFirstData();
            // echo "<pre>";
            // print_r($customerQuote1);
            if (!$customerQuote1) {
                // echo "in if condition";
                // $data = $this->load($quoteId);
                // $data = $this->getData();
                // print_r($data['customer_id']);
                $data1 = [
                    'quote_id' => $quoteId,
                    'customer_id' => $customer_id
                ];
                // $data->addData('custpomer_id',$customer_id)->setData($data->getData())->save();
                $this->setData($data1)->save();
            } else {
                // $customerQuote1 = $customerQuote1->getData();
                $customerQuote = Mage::getSingleton('sales/quote')->getCollection()->addFieldToFilter('customer_id', $customer_id)->addFieldToFilter('order_id', 0)->addFieldToFilter('quote_id', $customerQuote1->getQuoteId())->getFirstData();
                // $customerQuote = Mage::getSingleton('sales/quote')->getCollection()->addFieldToFilter('customer_id',$customer_id)->addFieldToFilter('order_id',0)->addFieldToFilter('quote_id',$customerQuote1['quote_id'])->getFirstItem();
                $this->load($customerQuote->getId());
                // Mage::getSingleton('core/session')->set('quote_id',$customerQuote1->getQuoteId());
                // Mage::getSingleton('core/session')->set('quote_id',$customerQuote1['quote_id']);
            }
        } else {
            // echo "no quote";die;
            $this->load($quoteId);
            if (!$this->getId()) {
                $quote = Mage::getModel('sales/quote')
                    ->setData(
                        [
                            'tax_percent' => 0,
                            'grand_total' => 0,
                        ]
                    )
                    ->save();
                Mage::getSingleton('core/session')->set('quote_id', $quote->getId());
                $this->load($quote->getId());
            }
        }

        //echo $quoteId;
    }



    public function addProduct($product)
    {

        $this->initQuote();

        if ($this->getId()) {


            Mage::getmodel('sales/quote_item')->additem($this, $product['product_id'], $product['quantity']);
        }
        $this->save();
    }

    public function getItemCollection()
    {

        return Mage::getmodel('sales/quote_item')->getCollection()->addFieldToFilter('quote_id', $this->getId());
    }

    public function convert()
    {

        $this->initQuote();
        if ($this->getId()) {

            $order = $this->convertOrder();

            $payment =  $this->convertPayment();
            $shipping =  $this->convertShipping();
            $order =  $this->orderNumber($order);
            $order->addData('shipping_id', $shipping->getId())
                ->addData('payment_id', $payment->getId())
                ->addData('status', 'Pending')->save();
            $this->convertCustomer($order);
            $quoteData = $this->addData('order_id', $order->getId())->save();
            $this->convertItem($order);
        }
    }

    public function convertItem($order)
    {

        foreach ($this->getItemCollection()->getData() as $_item) {

            $product = $_item->getProduct();
           $orderItems =  Mage::getmodel('sales/order_item')->setData($_item->getData())

                ->addData('order_id', $order->getId())

                ->removeData('item_id')

                ->removeData('quote_id')
                ->addData('product_name', $product->getName())
                ->addData('product_color', $product->getColor())
                ->save();
        }
    }
    public function convertOrder()
    {

        return $data =  Mage::getmodel('sales/order')

            ->setData($this->getData())
            ->removeData('quote_id')
            ->removeData('shipping_id')
            ->removeData('payment_id')
            ->removeData('order_id')
            ->removeData('customer_id');
    }
    public function orderNumber($order)
    {

        $count = sizeof($order->getCollection()->getData());

        $count += 2;

        $order->addData('order_number', $count);
        return $order;
    }
    public function addPayment($data)
    {

        $this->initQuote();
        $payment = Mage::getmodel('sales/quote_payment')->addpaymentMethod($data);

        $this->addData('payment_id', $payment->getId())->save();
    }

    public function addShipping($data)
    {

        $shipping = Mage::getmodel('sales/quote_shipping')->addShippingMethod($data);


        $this->addData('shipping_id', $shipping->getId())->save();
    }

    public function addCustomer($data)
    {

        $this->initQuote();
        $customerAddress = Mage::getmodel('sales/quote_customer');

        $quoteCustomer = $customerAddress->getCollection()->addFieldToFilter('quote_id', $this->getId())->getFirstData();
        $quoteCustomerId = ($quoteCustomer && $quoteCustomer->getId()) ? $quoteCustomer->getId() : 0;
        //print_r($itemId);

        $customerId = Mage::getSingleton('core/session')->get('logged_in_customer_id');
        $customerModel = Mage::getmodel('customer/customer')->load($customerId);
        $customerEmail = $customerModel->getCustomerEmail();

        $customerAddress->setData($data)
            ->addData('quote_customer_id', $quoteCustomerId)
            ->addData('quote_id', $this->getId())
            ->addData('customer_id', $customerId)
            ->addData('email', $customerEmail);
        $customerAddress->save();

        $this->addData('customer_id', $customerId)->save();
        //print_r($customerAddress);               
    }

    public function convertPayment()
    {

        $this->initQuote();
        $data = Mage::getmodel('sales/quote_payment')->getCollection()->addFieldToFilter('quote_id', $this->getId())->getFirstData();

        $orderPayment = Mage::getmodel('sales/order_payment')->setData($data->getData())
            ->removeData('payment_id')
            ->save();

        return $orderPayment;
    }

    public function convertShipping()
    {

        $this->initQuote();
        $data = Mage::getmodel('sales/quote_shipping')->getCollection()->addFieldToFilter('quote_id', $this->getId())->getFirstData();

        $orderShipping = Mage::getmodel('sales/order_shipping')->setData($data->getData())
            ->removeData('shipping_id')->save();


        return $orderShipping;
    }

    public function convertCustomer($order)
    {

        $this->initQuote();
        $data = Mage::getmodel('sales/quote_customer')->getCollection()->addFieldToFilter('quote_id', $this->getId())->getFirstData();


        Mage::getmodel('sales/order_customer')
            ->setData($data->getData())->addData('order_id', $order->getId())
            ->removeData('quote_id')
            ->removeData('quote_customer_id')
            ->save();
    }
}
