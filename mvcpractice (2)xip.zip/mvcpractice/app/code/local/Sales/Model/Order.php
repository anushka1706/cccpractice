<?php

class Sales_Model_Order extends Core_Model_Abstract{

    public function init()
    {

        $this->resourceClass = "Sales_Model_Resource_Order";
        $this->collectionClass = "Sales_Model_Resource_Collection_Order";
        $this->_modelClass = "sales/order";
    }

    // protected function _beforeSave(){

    

    // }

    public function getItemCollection(){

        return Mage::getmodel('sales/order_item')->getCollection()->addFieldToFilter('order_id', $this->getId());

    }

    public function addPayment($data){

        $this->initQuote();
        $data = Mage::getmodel('sales/order_payment')->setData($data)->addData('quote_id', $this->getId())->save();

        $this->addData('payment_id', $data->getId())->save();

    }

public function addShipping($data){

    
    $this->initQuote();
    $data = Mage::getmodel('sales/order_shipping')->setData($data)->addData('quote_id', $this->getId())->save();

    $this->addData('shipping_id', $data->getId())->save();

}

public function addCustomer($data){

    $this->initQuote();
       
        $data = Mage::getmodel('sales/quote_customer')->setData($data)->addData('quote_id', $this->getId())
            
            ->save();

}

}