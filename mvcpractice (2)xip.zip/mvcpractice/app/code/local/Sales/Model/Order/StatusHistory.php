<?php

class Sales_Model_Order_StatusHistory extends Core_Model_Abstract
{

    public function init()
    {
        $this->resourceClass = "Sales_Model_Resource_Order_StatusHistory";
        $this->collectionClass = "Sales_Model_Resource_Collection_Order_StatusHistory";
        $this->_modelClass = "Sales/Order_StatusHistory";
    }

    protected function _beforeSave()
    {
        $orderData = $this->getItemCollection();
        print_r($orderData);

        if ($orderData) {
            echo $orderData->getTo_Status();
            $to_status = $orderData->getToStatus();

            $this->addData('from_status', $to_status);
        } else {
            $defult = 'Place Order';
            $this->addData('from_status', $defult);
        }
        $this->addData('action_by', 1);
    }
    public function getItemCollection()
    {

        return Mage::getmodel('Sales/Order_StatusHistory')->getCollection()
            ->addFieldToFilter('order_id', $this->getOrder_Id())
            ->addFieldToOrderBy('history_id DESC')
            ->getFirstData();
    }
}
