<?php

class Sales_Model_Order_Item extends Core_Model_Abstract{
    
    protected $_product = null;
        public function init()
        {
    
            $this->resourceClass = "Sales_Model_Resource_Order_Item";
            $this->collectionClass = "Sales_Model_Resource_Collection_Order_Item";
            $this->_modelClass = "sales/order_item";
        }

        protected function _beforeSave(){

            //unsetting item_id of quote item
        }
        public function getProduct()
        {
    
            if(is_null($this->_product)){
            $this->_product = Mage::getmodel('catlog/product')->load($this->getProductId());
        }
    
        return $this->_product;
    }
    
    
}