<?php

class Core_Controller_Admin_Action extends Core_Controller_Front_Action
{

    protected $_allowActions = [];

    public function init()
    {


        if ($this->getRequest()->getModuleName() == 'admin' && !in_array($this->getRequest()->getActionName(), $this->_allowActions)) {

            $session = Mage::getSingleton('core/session')->get('logged_in_admin_username');
            if (empty($session)) {
                $this->setRedirect('admin/account/login');
            }
        }
    }
}
