<?php

class Core_Controller_Front
{

  public function init()
  {

    Mage::getSingleton('core/session');
    $request = Mage::getModel('core/request');
    $actionName = $request->getActionName() . 'Action';



    $classname = $request->getFullControllerClass();



    $controller = new $classname();

    //echo $controller;


    $controller->$actionName();
  }
}
