<?php
class Core_Model_Abstract
{
    protected $data = [];
    protected $resourceClass = '';
    protected $collectionClass = '';
    protected $resource = null;
    protected $collection = null;

    protected $_modelClass = '';
    public function __construct()
    {
        $this->init();
    }

    public function __call($name, $args)
    {
        // $name = strtolower(substr($name, 3));
        $name = $this->camelTodashed(substr($name, 3));
        return isset($this->data[$name])
            ? $this->data[$name]
            : "";
    }
    public function dashesToCamelCase($string, $capitalizeFirstCharacter = false)
    {
        $str = str_replace(' ', '', ucwords(str_replace('-', ' ', $string)));
        if (!$capitalizeFirstCharacter) {
            $str[0] = strtolower($str[0]);
        }
        return $str;
    }
    public function camelTodashed($className)
    {
        return strtolower(preg_replace('/([a-zA-Z])(?=[A-Z])/', '$1_', $className));
    }

    public function init()
    {
    }


    protected function _beforeSave()
    {

        return $this;
    }

    protected function _afterSave()
    {

        return $this;
    }


    public function setResourceClass($resourceClass)
    {
    }
    public function setCollectionClass($collectionClass)
    {
    }

    public function setId($id)
    {

        print_r($id);
        $this->data[$this->getResource()->getPrimaryKey()] = $id;
        return $this;
    }

    public function getId()
    {

        return isset($this->data[$this->getResource()->getPrimaryKey()]) ?
            $this->data[$this->getResource()->getPrimaryKey()]
            : false;
    }
    public function getResource()
    {

        return new $this->resourceClass();
    }
    public function getCollection()
    {

        $collection = new $this->collectionClass();
        // $collection->getModelClass();
        //   print_r($collection);

        $collection->setResource($this->getResource())->setModel($this->_modelClass);
        $collection->select();

        //print_r($collection);
        return $collection;
    }



    public function __set($key, $value)
    {
    }
    public function __get($key)
    {
    }

    public function __unset($key)
    {
    }
    public function getData($key = null)
    {

        return $this->data;
    }
    public function setData($data)
    {

        $this->data = $data;
        return $this;
    }
    public function addData($key, $value)
    {

        $this->data[$key] = $value;
        return $this;
    }
    public function removeData($key)
    {

        unset($this->data[$key]);
        return $this;
    }
    public function save()
    {

        // print_r($this);


        $this->_beforeSave();

        $this->getResource()->save($this);

        $this->_afterSave();

        // echo "saveeee";
        // print_r($this);

        return $this;
    }
    public function load($id, $column = null)
    {

        // echo get_class($this->getResource());

        $this->data = $this->getResource()->load($id, $column);

        //print_r($this->data);
        // print_r($this);
        return $this;
    }
    public function delete()
    {

        $this->getResource()->delete($this);
        return $this;
    }

    public function select()
    {

        $this->getResource()->select();
        return $this;
    }
}
