<?php

class Core_Model_DB_Adapter
{

    public $config = [
        "host" => 'localhost',
        "user" => 'root',
        "password" => '',
        "db" => 'ccc_practice'
    ];
    public $connect = null;

    public function connect()
    { {
            if ($this->connect === null) {
                $this->connect = mysqli_connect($this->config["host"], $this->config["user"], $this->config["password"], $this->config["db"]);
                // echo "connected";
            }
            return $this->connect;
        }
    }



    public function fetchAll($query)
    {

        $result = mysqli_query($this->connect(), $query);

        return $result->fetch_all(MYSQLI_ASSOC);
    }
    public function fetchPairs($query)
    {
    }
    public function fetchOne($query)
    {
    }
    public function fetchRow($query)
    {

       // echo $query;
        $row = [];

        $data = mysqli_query($this->connect(), $query);
       

        while ($_row = mysqli_fetch_assoc($data)) {

            $row = $_row;
        }
        return $row;
    }
    public function insert($query)
    {

        echo $query;
        $res = mysqli_query($this->connect(), $query);



        if ($res) {

            return mysqli_insert_id($this->connect());
        }
    }
    public function update($query)
    {

        $res = mysqli_query($this->connect(), $query);



        if ($res) {

            return true;
        }
    }
    public function delete($query)
    {
        echo $query;
        $res = mysqli_query($this->connect(), $query);



        if ($res) {

            return true;
        }
    }
    public function query($query)
    {
    }
}
