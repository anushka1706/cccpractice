<?php

class Core_Model_Resource_Abstract{

    protected $_tableName=null;
    protected $_primaryKey=null;

    public function getPrimaryKey(){

        return $this->_primaryKey;


    }

    public function getAdapter(){

        return new Core_Model_DB_Adapter();
    }

    public function tableName(){

        return $this->_tableName;
    }
    public function getResource(){

        }

    public function load($id,$column=null){

        

        $sql= "select * from {$this->tableName()} where {$this->getprimarykey()}={$id} ";

        $adapter=$this->getAdapter();
        $result=$adapter->fetchRow($sql);
        // echo "sqliiiiii";
        // print_r($result);
        return $result;
   }

public function save( $product){
// echo "here";
// print_r($product);
$data = $product->getData();

//print_r($data);


if(isset($data[$this->getPrimaryKey()]) && !empty($data[$this->getPrimaryKey()])){

    

    unset($data[$this->getprimarykey()]);

    // print_r($product->getId());
    
    $sql = $this->updateSql($this->tableName(),$data,[$this->getPrimaryKey()=>$product->getId()]);

    $id=  $this->getAdapter()->update($sql);

   // print_r($product);
    
}

else{

 

$sql = $this->insertSql($this->tableName(),$data);
// print_r($data);
 
$id=  $this->getAdapter()->insert($sql);


$product->setId($id);



//print_r($product);
}

//print_r($product);

    }

public function insertSql($tableName,$data){

   
echo "insert";
     $columns=[];
    $values=[];
    foreach($data as $field =>$value){
        $columns[]="`{$field}`";
        $values[]="'" .addslashes($value)."' ";
    }
    $columns=implode(",",$columns);
    $values=implode(",",$values);
    echo "INSERT INTO {$tableName} ({$columns}) VALUES ({$values});";
    return "INSERT INTO {$tableName}".
    "({$columns}) VALUES ({$values});";
} 


public function selectSql($table,$column){

    $sql= "";

    $columns = [];
    if($column=['*']){
        
        

        $sql.= "SELECT *  FROM {$table};";
    }

    else{
        foreach($column as $fields){

            $columns[]= "{$fields}";
        }
        $columns =   implode(",",$columns);

        $sql.= "SELECT {$columns} FROM {$table};";

    }
//echo $sql;
    return $sql;


}

public function updateSql($table,$data,$where){

        $columns = $wherecondition = [];
        foreach($data as $_fields=>$_values){
            $columns[] = "`$_fields` = "."'$_values'";
        }
    $columns = implode(" , ",$columns);
    
    foreach($where as $_fields=>$_values){
        $wherecondition[] = "$_fields ="."$_values";
    }
    $wherecondition = implode("AND",$wherecondition);
    
    // echo "UPDATE $table SET $columns WHERE $wherecondition;";
     return "UPDATE $table SET $columns WHERE $wherecondition;";

    }
    

    // public function update($table,$data,$where){

    //     $this->getAdapter()->update($this->updateSql($table,$data,$where));
    // }

public function deleteSql($table,$where){

    
        $wherecon = [];
        
        foreach($where as $_fields=>$_values){
    
            $wherecon[] = "$_fields= "."$_values";
    
        }
        $wherecon = implode("AND",$wherecon);
         return "DELETE FROM $table WHERE $wherecon;";
    }

// public function select($table,$column){

    

//     $query = $this->selectSql($table,$column);
// $this-> = $this->getAdapter()->fetchAll($query);

// return  $this->data;


// }

public function delete( $product){

  $this->getAdapter()->delete( $this->deleteSql($this->tableName(),[$this->getPrimaryKey()=>$product->getId()]));

}

}

  

    
