<?php

class Core_Model_Resource_Collection_Abstract
{
    protected $_resource = null;
    protected $_select = [];

    protected $_isLoaded = false;

    protected $_modelClass = null;

    protected $_data = [];
    public function setResource(Core_Model_Resource_Abstract $resource)
    {
        $this->_resource = $resource;
        // print_r($resource);

        return $this;
    }

    public function getFirstData()
    {

        if (!$this->_isLoaded) {
            $this->load();
        }
       
        return $this->_data[0];
    }

    public function setModel($model)
    {


        $this->_modelClass = $model;
        return $this;
    }

    public function getData()
    {
        if (!$this->_isLoaded) {
            $this->load();
        }
        return $this->_data;
    }


    public function select()
    {


        $this->_select['from'] = $this->_resource->tableName();

        //print_r($this->_select);
        return $this;
    }


    public function addFieldToFilter($column, $filter)
    {
        $this->_select['where'][$column][] = $filter;
        // echo "<pre>";
        //         print_r($this->_select);


        return $this;
    }



    public function load()
    {
        $sql = "SELECT * FROM {$this->_select['from']} ";
        if (isset($this->_select['where']) && count($this->_select['where'])) {

            
            $whereCond = [];
            foreach ($this->_select['where'] as $_field => $_filters) {

                // print_r($_field);
                // print_r($_filters);
                foreach ($_filters as $_value) {
                    //print_r($_value);   
                    if (!is_array($_value)) {


                        $_value = ['eq' => $_value];
                    }
                }
                foreach ($_value as $_k => $_v) {
                    //print_r($_value);
                    // print_r($_k);
                    // print_r($_v);

                    switch ($_k) {

                        case 'order by':
                            if ($this->_select['where'] = ' ') {
                               
                                $whereCond[] = " ORDER BY  {$_v} ";
                            } 

                            break;


                        case 'limit':
                            if ($this->_select['where'] = ' ') {

                                $whereCond[] = " LIMIT {$_v} ";
                            } else {

                                $whereCond[] = "`$_field` LIMIT '{$_v}' ";
                            }


                            break;

                        case 'gt':
                            $whereCond[] = "`$_field` > '{$_v}' ";
                            break;

                        case 'like':


                            $whereCond[] = "$_field LIKE '{$_v}'";


                            //  print_r($whereCond);
                            break;

                            case 'IN':
                               
                                $v=[];
                                foreach($_v as $val)
                                {
                                  $v[]="'".addslashes($val)."'";
                                }
                                $_v=implode(',', $v);
                                $whereCond[]= "`$_field` IN ({$_v})";
                                break;

                        case 'eq':
                            $whereCond[] = "$_field = '{$_v}' ";
                            //print_r($_field);
                            break;

                        case 'between':

                            $whereCond[] = "`$_field` between  {$_v[0]} and {$_v[1]} ";

                            break;

                        case 'group by':


                            $whereCond[] = " GROUP BY {$_v} ";


                            //print_r($_field);

                            break;

                            // case 'having':

                            //         $whereCond[] = " HAVING {$_v} ";
                            //        // print_r($_v);

                            //         break;

                        case 'not equal':
                            $whereCond[] = "`$_field` != '{$_v}' ";
                            // print_r($_v);

                            break;

                        case 'lteq':

                            $whereCond[] = "`$_field` <= '{$_v}' ";
                            // print_r($_v);

                            break;

                        case 'gteq':

                            $whereCond[] = "`$_field` >= '{$_v}' ";
                            // print_r($_v);

                            break;
                            // default:
                            // $whereCond[] = "";
                    }
                }
            }
            
            if ($this->_select['where'] == ' ') {

                // echo "skjf";

                $whereCond = implode(" ", $whereCond);

                $sql .= "$whereCond";
            } else {

                

                $whereCond = implode(" AND ", $whereCond);

                

                $sql .= "WHERE $whereCond";
            // }

           
        }
    }
    if(isset($this->_select['order by'])){

        $sql .= 'ORDER BY'." ". $this->_select['order by'];
    }

    
        $result = $this->_resource->getAdapter()->fetchAll($sql);

        //print_r($result);
        foreach ($result as $row) {
            $this->_data[] = Mage::getmodel($this->_modelClass)->setData($row);
        }
        $this->_isLoaded = true;

        // print_r($this->_data);


        return $this;
    
}

public function addFieldToOrderBy($filter){

    
    $this->_select['order by'] = $filter;



    return $this;
}


}

