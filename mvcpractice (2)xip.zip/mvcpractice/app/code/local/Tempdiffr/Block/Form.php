<?php

class Tempdiffr_Block_Form extends Core_Block_Template
{

    public function getTemp()
    {

        return Mage::getmodel('tempdiffr/tempdiffr');
    }


    public function getMunits()
    {

      
      return  $mapping = [
            'c' => 'celsius',
            'k' => 'kelvin',
            'f' => 'fahrenheit'
        ];

        
    }
}
