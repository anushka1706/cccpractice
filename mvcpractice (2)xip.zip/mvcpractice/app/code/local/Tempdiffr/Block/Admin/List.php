<?php

class Tempdiffr_Block_Admin_List extends Core_Block_Template{

    public function getTempData(){

        return Mage::getmodel('tempdiffr/tempdiffr');
    }
}