<?php

class Tempdiffr_Controller_User extends Core_Controller_Front_Action
{


    public function formAction()
    {
        if (!$this->getRequest()->isPost()) {

            $layout = $this->getLayout();

            $child = $layout->getChild('content');

            $form = $layout->createBlock('tempdiffr/form')->setTemplate('tempdiffr/form.phtml');

            $child->addChild('form', $form);

            $layout->toHtml();
        } else {

            echo "777770";
        }
    }



    public function saveAction()
    {


        $data = $this->getRequest()->getParams('t_data');

        print_r($data);

        $tempModel = Mage::getmodel('tempdiffr/tempdiffr');

        $temp = $tempModel->setData($data)->save();

       // $id = Mage::getSingleton('core/session')->set('user_name',$temp->getUserName());

        

        print_r($temp);


        $unitOne = $data['unit_one'];
        $unitTwo = $data['unit_two'];
        $temp1 = $data['tempreture_one'];
        $temp2 = $data['tempreture_two'];
        $operation = $data['operation'];
        // $celsius1 = '';
        // $celsius2 = '';
        $result = 0;
        print_r($data);
        // echo $temp1;

        if ($unitOne !='celsius' && $unitTwo != 'celsius') {

            switch ($unitOne) {

                case ('c'):

                    break;

                case ('f'):

                    $temp1 = (5  * $temp1) / 9 - 32;
                    // $temp1=777;
                    break;

                case ('k'):

                    $temp1 = $temp1 - 273.15;
            }




            switch ($unitTwo) {

                case ('c'):

                    break;

                case ('f'):

                    $temp2 = ((5  * $temp2) / 9 )- 32;


                    break;

                case ('k'):

                    $temp2 = $temp2 - 273.15;
                    break;
            }
        } if($unitOne == 'celsius' && $unitTwo== 'celsius'){
            $result = $temp1+$temp2;
        }

            

        switch ($operation) {

            case ('add'):

                $result = $temp1 + $temp2;

                // echo $result;
                break;

            case ('minus'):

                $result = $temp1 - $temp2;
                //echo $result;
                break;
        }
      



        // echo $temp1;
        // echo "<br>";
        // echo $temp2;

        //echo $result;
        $session = $temp->getId();
        Mage::getSingleton('core/session')->set('user_name',$session);
$id= Mage::getSingleton('core/session')->get('user_name');
       echo $id;
        $model = Mage::getmodel('tempdiffr/tempdiffr')->setdata([
            'id' => $temp->getId(),
'session_id'=>$id,
            'result' => $result
        ])->save();
        //$this->setRedirect("tempdiffr/user/form?id={$tempModel->getId()}");

    }
}
