<?php

class Tempdiffr_Model_Tempdiffr extends Core_Model_Abstract{

    public function init(){

        $this->resourceClass="Tempdiffr_Model_Resource_Tempdiffr";
        $this->collectionClass="Tempdiffr_Model_Resource_Collection_Tempdiffr";
        $this->_modelClass = "Tempdiffr/Tempdiffr";
    }
    
}