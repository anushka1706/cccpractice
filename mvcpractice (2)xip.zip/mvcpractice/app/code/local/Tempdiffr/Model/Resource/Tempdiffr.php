<?php

class Tempdiffr_Model_Resource_Tempdiffr extends Core_Model_Resource_Abstract{

    public function __construct(){

        $this->init();
    }
//above all code move to resource abstract


    public function init(){


        $this->_tableName = "ccc_temp_diff";
        $this->_primaryKey = "id";
    }

    
}