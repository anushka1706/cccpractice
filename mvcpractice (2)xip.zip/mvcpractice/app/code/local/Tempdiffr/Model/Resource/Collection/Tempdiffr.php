<?php

class Tempdiffr_Model_Resource_Collection_Tempdiffr extends Core_Model_Resource_Collection_Abstract{

    
}